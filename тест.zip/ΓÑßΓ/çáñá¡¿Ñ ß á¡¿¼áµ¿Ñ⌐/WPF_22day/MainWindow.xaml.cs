﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_22day
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Boolean FRMove = true;
        private Point ellipsePoint = new Point(0, 100);      

        public MainWindow()
        {
            InitializeComponent();

            if (ellipsePoint.X == media.Width) FRMove = false;
            if (ellipsePoint.X == 0) FRMove = true;
            if (FRMove) ellipsePoint.X += 1;
            else ellipsePoint.X -= 1;
            media.Clip = new EllipseGeometry(ellipsePoint, 50, 50);
        }

    }
}
