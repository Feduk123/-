﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private Storyboard myStoryboard;
        public MainWindow()
        {
            InitializeComponent();

        }
        private void myRectangleLoaded(object sender,
        RoutedEventArgs e)
        {
            myStoryboard.Begin(this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {


        }

        private void MainWindow_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void sfd_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void page_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Page1 page1 = new Page1();
            page1.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Page2 page2 = new Page2();
            page2.Show();
        }
    }
}


