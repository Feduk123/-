﻿using System;
using library1;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library1
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] mas = new double[] { 4, 7, 1, 14, 16, -3, -5, -13 };
            


            Console.Read();
        }
    }
}
